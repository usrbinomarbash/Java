package com.glovo.model;


public enum OrderStatus{
    PENDING,
    DISPATCHED,
    DELIVERED
}