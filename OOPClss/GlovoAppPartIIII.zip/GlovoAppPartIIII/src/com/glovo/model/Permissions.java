package com.glovo.model;

public enum Permissions {
    MANAGE_USERS,
    VIEW_REPORTS,
    HANDLE_DISPUTES
}