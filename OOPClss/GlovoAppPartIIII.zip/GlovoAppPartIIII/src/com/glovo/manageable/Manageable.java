package com.glovo.manageable;

public interface Manageable{
    void manageOrder();
    public void manageProfile();
}